# Pythonic Perambulations Theme

This theme was adapted from that at https://github.com/danielfrg/danielfrg.github.io-source; the original is released under the Apache v2.0 license.
Adaptations are contained in this directory.